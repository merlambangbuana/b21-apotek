======================================================
    APLIKASI LOGIN SEDERHANA DENGAN CODEIGNITER
======================================================
Aplikasi ini di unduh di situs www.kioscoding.com


untuk membuka aplikasi silahkan ketik alamat berikut
===================================
http://localhost/kioscoding/login/
===================================

untuk tutorial lainnya silahkan kunjungi
========================================
	   www.kioscoding.com
========================================